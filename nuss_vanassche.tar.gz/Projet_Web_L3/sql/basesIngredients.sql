INSERT INTO `ingredient` (`nomIngredient`, `calories`, `Lipides`, `Glucides`, `Proteines`, `Popularite`, `isGrammes`) VALUES ('sel', '0', '0', '0', '0', NULL, '1');
INSERT INTO `ingredient` (`nomIngredient`, `calories`, `Lipides`, `Glucides`, `Proteines`, `Popularite`, `isGrammes`) VALUES ('poivre', '0', '0', '0', '0', NULL, '1');
INSERT INTO `ingredient` (`nomIngredient`, `calories`, `Lipides`, `Glucides`, `Proteines`, `Popularite`, `isGrammes`) VALUES ('farine de blé', '360', '1.5', '76', '10', NULL, '1');
INSERT INTO `Utilisateur` (`login`, `adresse`, `mot_de_passe`, `nom`, `prenom`) VALUES ('root','root@admin.com','435b41068e8665513a20070c033b08b9c66e4332','root','root');
