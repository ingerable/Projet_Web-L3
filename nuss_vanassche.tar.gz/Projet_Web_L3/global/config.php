<?php

const SQL_DSN = 'mysql:host=osr-bdd2.u-strasbg.fr;
                  dbname=jnuss';
const SQL_USERNAME = 'jnuss';
const SQL_PASSWORD = 'jnpa1128';
