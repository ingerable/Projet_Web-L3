# Projet WEB L3

## Questions fonctionnalit�es

* Doit on impl�menter le syst�me de note pour une recette ? 

* Est ce que l'utilisateur doit pouvoir modifier le nombre de personnes
  et donc les quantit� des ingr�dients s'adapte



## To Do List :+1:


## Sujet projet

### Site de recettes.

- [x] a) Ecrire  les  pages  du  site  permettant  �  un  utilisateur  de  cr�er  un  compte,  de  se 
	connecter et de se d�connecter. Le mot depasse de l�utilisateur ne sera pas stock� tel quel 
	dans la base, seul le hash du mot de passe (application d�une fonction de hachage, par exemple 
	sha1) sera stock� dans la base.

- [x] b) Ecrire la page web permettant de visualiser les recettes.

- [x] c) Ecrire les pages web permettant de cr�er une recette et d'y ajouter des ingr�dients

- [ ] d) Ajouter  la  possibilit�  de d�finir  un  planning  de  plats  �  cuisiner  (recettes)  pour  la semaine

- [x] c) e) Ajouter  la  possibilit�  de  rechercher  des recettes  par  ingr�dients  et  de  trier  les r�sultats

### Administration du site de recettes.

- [ ] a) Cr�er les pages permettant � un administrateur du site de se connecter de voir les utilisateurs, lesrecetteset les ingr�dients. 

- [ ] b) Permettre  �  un  administrateur  de  supprimer  ou  de  modifier  les  utilisateurs,  les recettes et les ingr�dients.


### TO DO 

- [ ] 1. Illustration �tape

- [x] 2. Champ suppl�mentaire pour determiner l'unit� de mesure utilis� pour un ingr�dient

- [ ] 3. V�rifier que l'utilisateur soit bien connect� pour acc�der � chaque page
