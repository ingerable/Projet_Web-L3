<footer>
	<p>2-7 2-7</p>
	<p>C'est le site des recettes</p>
</footer>
