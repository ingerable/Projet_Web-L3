<h1 class="error text-center">
	Bad request
</h1>
